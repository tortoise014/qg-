package com.itheima.web.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class ContextLoderListener implements ServletContextListener {
    public void contextInitialized(ServletContextEvent servletContextEvent) {
//加载
        System.out.println("啦啦啦");
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
//释放
    }
}
