package com.itheima.service;

import com.itheima.mapper.BrandMapper;
import com.itheima.mapper.UserMapper;
import com.itheima.pojo.Brand;
import com.itheima.pojo.User;
import com.itheima.util.SqlSessionFactoryUtils;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

public class UserService {
    //调用SqlSessionFactoryUtils里面的SqlSessionFactory
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();
    /**
     * 登陆方法
     * @param userName
     * @param password
     * @return
     */
    public User login(String userName,String password){
        //获取sqlSession
        SqlSession sqlSession = factory.openSession();
        //调用mapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        //调用方法
        User user = mapper.select(userName, password);
        sqlSession.close();
        return user;
    }


    /**
     * 注册方fa
     * @return
     */
    public boolean register(User user){
        //获取sqlSession
        SqlSession sqlSession = factory.openSession();
        //调用mapper
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
      //判断是否存在
        User u=mapper.selectByUsername(user.getUsername());
        if(u==null) {
//不存在
            mapper.add(user);
            sqlSession.commit();}


        sqlSession.close();
        return u==null;


    }

}
