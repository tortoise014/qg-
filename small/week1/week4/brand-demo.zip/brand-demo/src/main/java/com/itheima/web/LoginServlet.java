package com.itheima.web;

import com.itheima.pojo.User;
import com.itheima.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    private UserService service=new UserService();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String remember = request.getParameter("remember");

        //调用service
        User user = service.login(username, password);
        if(user!=null){
//登陆成功,跳转到selectAllServlet
            //重定向
            if ("1".equals(remember)) {
            //勾选了
                //创建cookie
                Cookie c_username=new Cookie("username",username);
                Cookie c_password=new Cookie("password",password);
                //发宋
                c_username.setMaxAge(60*60*24*7); // 设置 Cookie 的过期时间为 1 小时
                c_password.setMaxAge(60*60*24*7); // 设置 Cookie 的过期时间为 1 小时

                response.addCookie(c_password); // 将 Cookie 添加到 HTTP 响应中，发送给客户端
                response.addCookie(c_username); // 将 Cookie 添加到 HTTP 响应中，发送给客户端
            }
                //将成功登陆的放到session里面
                HttpSession session = request.getSession();

           session.setAttribute("user",user);
            String contextPath = request.getContextPath();
            response.sendRedirect(contextPath+"/selectAllServlet");
        }else{
//失败,跳到注册页面
            //存错误信息到request
            request.setAttribute("login_msg","用户名或密码错误");
            request.getRequestDispatcher("/login.jsp").forward(request,response);
        }

    }
}
