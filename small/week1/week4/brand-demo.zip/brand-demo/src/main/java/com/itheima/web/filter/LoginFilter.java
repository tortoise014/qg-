package com.itheima.web.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * 登陆验证拦截器
 */
@WebFilter("/*")
public class LoginFilter implements Filter {

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest request=(HttpServletRequest) req;

//和登录注册相关
        String[] urls={"/login.jsp","/imgs/","/css/","/loginServlet","/register.jsp","/registerServlet","/checkCodeServlet"};
        String url = request.getRequestURL().toString();
        for (String s : urls) {
            if(url.contains(s)){
                //
                chain.doFilter(req, resp);
                return;
            }
        }

        HttpSession session=request.getSession();
        Object user = session.getAttribute("user");

        if(user!=null){
            //已经登陆过了
            chain.doFilter(req, resp);

        }else{
            //没有登陆非法请求
            //跳转到登陆,给出提示信息
            request.setAttribute("login_msg","请先登录");
            request.getRequestDispatcher("/login.jsp").forward(request,resp);

        }

    }


    public void destroy() {
    }



    public void init(FilterConfig config) throws ServletException {

    }

}
